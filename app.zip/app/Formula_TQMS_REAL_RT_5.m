%% part4 TQMS-MRM数据处理，找真实保留时间
tic
%% 
rawdata = table2cell(readtable(appreadexcel));%按模板整理每个复方的药味及路径信息，一次只放一个复方，正负离子模式分成两个表;原始数据命名时需标记pos和neg


%% 修改文件名
% for i = 1:length(rawdata)
%     % 修改第2列
%     newStr2=split(rawdata(i,2),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr2(1,:) = [];
%     temp2 = strcat(pwd,newStr2);
%     rawdata(i,2) = temp2;
%     % 修改第3列
%     newStr3=split(rawdata(i,3),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr3(1,:) = [];
%     temp3 = strcat(pwd,newStr3);
%     rawdata(i,3) = temp3;
%     % 修改第4列
%     newStr4=split(rawdata(i,4),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr4(1,:) = [];
%     temp4 = strcat(pwd,newStr4);
%     rawdata(i,4) = temp4;
%     % 修改第5列
%     newStr5=split(rawdata(i,5),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr5(1,:) = [];
%     temp5 = strcat(pwd,newStr5);
%     rawdata(i,5) = temp5;
% end

%%=======================================

%% 创建一个存储处理结果的文件夹
if ~exist('result5','file')
    mkdir('result5')
end


delta_mz_tqms = 0.1;%Da
% delta_rt = 0.15;%min
% int_threshold = 150;%500,300

for m = 1:size(rawdata,1)
    for n = 1:2
        if n < 2
            sample_m = char(rawdata(m,1));
            pathway_cal = char(rawdata(m,2));
            pathway_real = char(rawdata(m,3));
            eval([sample_m,'_cal = table2cell(readtable("',pathway_cal,'"));']); %读入
            eval(['sample_calculation_rt = ',sample_m,'_cal;']);
            if eval(['size(sample_calculation_rt,2)<6'])
        eval(['fprintf("this file: ',sample_m,'_CAL_RESULTS_POS is empty.\n");']);
        eval(['xlswrite("result5\',sample_m,'_REAL_RT_POS.xlsx",sample_calculation_rt);']);
            else
            eval([sample_m,'_real = fopen("',pathway_real,'");']); %读入
            
            eval(['mrm_rawdata = textscan(',sample_m,'_real,"%s","Delimiter",",");']);%所有数据被存成一列
            mrm_rawdata = mrm_rawdata{1,1};%这一行加上才能用contains函数，mrm_rawdata才是文本格式
            eval(['fclose(',sample_m,'_real);']);
            
            mrmStruct = struct('ion_pair',[],'rt_int',[],'rt',[],'int',[]);
            
            scanCount = numel(find(contains(mrm_rawdata,'->')));%%通过扫描'->'字符，确定.csv文件中含有多少个离子对
            txtStruct.transition = repmat(mrmStruct,scanCount-1,1); %%通过scanCount值将txtStruct的维度进行repmat，复制scanCount-1次，因为第一个transition为TIC图，不包含离子对
            
            fprintf('Number of MS/MS scans: %d\n',scanCount);%将defaultstructure 按扫描数重复，并保存在transition中
            
            BeginRow = find(contains(mrm_rawdata,'->'));%在每一个transition中循环，提取名称、保留时间、强度三列信息
            EndRow = find(contains(mrm_rawdata,'->'))-1;
            
            EndRow(1) = []; EndRow(end+1) = size(mrm_rawdata,1);
            BeginRow(1) = []; EndRow(1) = [];%这一行是删掉qqq-mrm的第一行TIC图，剩余的就是提取的mrm图，注意当前需要删的仍是EndRow(1)，不能是2
            
            for i = 1:length(BeginRow)
                txt_scan = mrm_rawdata(BeginRow(i):EndRow(i),1);
                % Get tltle
                NameRow = find(contains(txt_scan,'->'));
                txtStruct.transition(i).ion_pair = txt_scan{NameRow,1};%提取每个离子对的标题名称
                % Get rt-int data
                tempMS = str2double(txt_scan(NameRow+4:end,1));
                temprt = tempMS(2:3:end);
                tempint = tempMS(3:3:end);
                temprt_int = [temprt,tempint];
                txtStruct.transition(i).rt = temprt;
                txtStruct.transition(i).int = tempint;
                txtStruct.transition(i).rt_int = temprt_int;
            end %得到的结果：第一列title，第二列保留时间和强度（其中第一列保留时间，第二列强度）
            
            extract_results = {};%title提出来后， 提取实际检测到的化合物名称，母离子和子离子  
            for i = 1:size(txtStruct.transition,1)
                parent_product = txtStruct.transition(i).ion_pair;
                index1 = find(parent_product == '(');%只能返回单一字符的位置，所有不能继续用->定位
                index2 = find(parent_product == '>');
                extract_results{i,2} = str2double(parent_product(index1+1:index2-2));%空格算一个字符，母离子
                index3 = find(parent_product == ')');
                extract_results{i,3} = str2double(parent_product(index2+2:index3-1));%子离子
                index4 = find(parent_product == '#');
                index5 = find(parent_product == ':');
                extract_results{i,1} = parent_product(index4+2:index5-1);%化合物名称
            end
            sample_real_rt = {};
            sample_real_rt(:,1) = sample_calculation_rt(:,1);%母离子(column1)从预测file中转移到real中
            sample_real_rt(:,2:4) = sample_calculation_rt(:,3:5);%子离子(column2)和(column3)保留时间转移
            sample_real_rt = cell2mat(sample_real_rt);%如果不转成double，cell不能运算保留时间偏差
            
            %eval(['index_sample = find(contains(sample(:,2),"',sample_m,'")==1);']);
            for i = 1:size(sample_calculation_rt,1)
                indexC = strfind(extract_results(:,1),sample_calculation_rt(i,6));%化合物名字匹配，找到预测和提取出来的名字一样的序号
                index = find(~(cellfun('isempty',indexC)));%不是空，即找到了名字一样的序号
                if isempty(index)
                    eval(['fprintf("compound has not been monitored, ',sample_m,'_cal line %d\n",i);']);
                else
                    for j = 1:size(index,1)
                        index_ion = find(abs(vpa(sample_calculation_rt(i,3),2))- extract_results(index(j),3) <= delta_mz_tqms &...%母离子匹配
                            abs(vpa(sample_calculation_rt(i,1),2)- extract_results(index(j,1),2)) <= delta_mz_tqms);%子离子匹配
                        if isempty(index_ion)
                            eval(['fprintf("check precusor-product ion in ',sample_m,'_cal line %d\n",i);']);
                        else
                            mrm_rt_int = txtStruct.transition(index(j)).rt_int;
                            index_rt = find(abs(mrm_rt_int(:,1) - sample_real_rt(i,4)) <= delta_rt);%找到保留时间偏差小于0.15min的几个点
                            [mrm_int,mrm_rt] = max(mrm_rt_int(index_rt,2));%在找到的几个点中取强度最高的那个点的数值和位置,max()
                            if mrm_int >= int_threshold %再判断最高强度有没有大于1000阈值
                                sample_real_rt(i,5) = mrm_rt_int(index_rt(mrm_rt),1);
                            else
                                sample_real_rt(i,5) = 0; %如果找到的保留时间下峰强度小于阈值，就赋值为0
                            end
                        end
                    end
                end
            end
            sample_real_rt = num2cell(sample_real_rt);
            sample_real_rt(:,6) = sample_calculation_rt(:,6);%compound name强度转移至file中
            eval(['xlswrite("result5\',sample_m,'_REAL_RT_POS.xlsx",sample_real_rt);']); %TQMS检测到的离子数量
            end
        else
            sample_real_rt = {};
            sample_calculation_rt = {};
            eval([sample_m,'_real = [];']);
            sample_m = char(rawdata(m,1));
            pathway_cal = char(rawdata(m,4));
            pathway_real = char(rawdata(m,5));
            eval([sample_m,'_cal = table2cell(readtable("',pathway_cal,'"));']); %读入
            eval(['sample_calculation_rt = ',sample_m,'_cal;']);
            if eval(['size(sample_calculation_rt,2)<6'])
        eval(['fprintf("this file: ',sample_m,'_CAL_RESULTS_NEG is empty.\n");']);
        eval(['xlswrite("result5\',sample_m,'_REAL_RT_NEG.xlsx",sample_calculation_rt);']);
            else
            eval([sample_m,'_real = fopen("',pathway_real,'");']); %读入
            
            eval(['mrm_rawdata = textscan(',sample_m,'_real,"%s","Delimiter",",");']);%所有数据被存成一列
            mrm_rawdata = mrm_rawdata{1,1};%这一行加上才能用contains函数，mrm_rawdata才是文本格式
            eval(['fclose(',sample_m,'_real);']);
            
            mrmStruct = struct('ion_pair',[],'rt_int',[],'rt',[],'int',[]);
            scanCount = numel(find(contains(mrm_rawdata,'->')));%%通过扫描'->'字符，确定.csv文件中含有多少个离子对
            txtStruct.transition = repmat(mrmStruct,scanCount-1,1); %%通过scanCount值将txtStruct的维度进行repmat，复制scanCount-1次，因为第一个transition为TIC图，不包含离子对
            
            fprintf('Number of MS/MS scans: %d\n',scanCount);%将defaultstructure 按扫描数重复，并保存在transition中
            
            BeginRow = find(contains(mrm_rawdata,'->'));%在每一个transition中循环，提取名称、保留时间、强度三列信息
            EndRow = find(contains(mrm_rawdata,'->'))-1;
            
            EndRow(1) = []; EndRow(end+1) = size(mrm_rawdata,1);
            BeginRow(1) = []; EndRow(1) = [];%这一行是删掉qqq-mrm的第一行TIC图，剩余的就是提取的mrm图，注意当前需要删的仍是EndRow(1)，不能是2
            
            for i = 1:length(BeginRow)
                txt_scan = mrm_rawdata(BeginRow(i):EndRow(i),1);
                % Get tltle
                NameRow = find(contains(txt_scan,'->'));
                txtStruct.transition(i).ion_pair = txt_scan{NameRow,1};%提取每个离子对的标题名称
                % Get rt-int data
                tempMS = str2double(txt_scan(NameRow+4:end,1));
                temprt = tempMS(2:3:end);
                tempint = tempMS(3:3:end);
                temprt_int = [temprt,tempint];
                txtStruct.transition(i).rt = temprt;
                txtStruct.transition(i).int = tempint;
                txtStruct.transition(i).rt_int = temprt_int;
            end%得到的结果：第一列title，第二列保留时间和强度（其中第一列保留时间，第二列强度）
            
            extract_results = {};    %title提出来后， 提取实际检测到的化合物名称，母离子和子离子
            for i = 1:size(txtStruct.transition,1)
                parent_product = txtStruct.transition(i).ion_pair;
                index1 = find(parent_product == '(');%只能返回单一字符的位置，所有不能继续用->定位
                index2 = find(parent_product == '>');
                extract_results{i,2} = str2double(parent_product(index1+1:index2-2));%空格算一个字符，母离子
                index3 = find(parent_product == ')');
                extract_results{i,3} = str2double(parent_product(index2+2:index3-1));%子离子
                index4 = find(parent_product == '#');
                index5 = find(parent_product == ':');
                extract_results{i,1} = parent_product(index4+2:index5-1);%化合物名称
            end
            sample_real_rt = {};
            sample_real_rt(:,1) = sample_calculation_rt(:,1);%母离子(column1)从预测file中转移到real中
            sample_real_rt(:,2:4) = sample_calculation_rt(:,3:5);%子离子(column2)和(column3)保留时间转移
            sample_real_rt = cell2mat(sample_real_rt);%如果不转成double，cell不能运算保留时间偏差
            
            for i = 1:size(sample_calculation_rt,1)
                indexC = strfind(extract_results(:,1),sample_calculation_rt(i,6));%化合物名字匹配，找到预测和提取出来的名字一样的序号
                index = find(~(cellfun('isempty',indexC)));%不是空，即找到了名字一样的序号
                if isempty(index)
                    eval(['fprintf("compound has not been monitored, ',sample_m,'_cal line %d\n",i);']);
                    %fprintf('compound has not been monitored, sample_calculation_rt:line %d\n',i);
                else
                    for j = 1:size(index,1)
                        index_ion = find(abs(vpa(sample_calculation_rt(i,3),2))- extract_results(index(j),3) <= delta_mz_tqms &...%母离子匹配
                            abs(vpa(sample_calculation_rt(i,1),2)- extract_results(index(j,1),2)) <= delta_mz_tqms, 1);%子离子匹配
                        if isempty(index_ion)
                            eval(['fprintf("check precusor-product ion in ',sample_m,'_cal line %d\n",i);']);
                            %fprintf('check precusor-product ion in sample_calculation_rt:line %d\n',i);
                        else
                            mrm_rt_int = txtStruct.transition(index(j)).rt_int;
                            index_rt = find(abs(mrm_rt_int(:,1) - sample_real_rt(i,4)) <= delta_rt);%找到保留时间偏差小于0.15min的几个点
                            [mrm_int,mrm_rt] = max(mrm_rt_int(index_rt,2));%在找到的几个点中取强度最高的那个点的数值和位置,max()
                            if mrm_int >= int_threshold %再判断最高强度有没有大于1000阈值
                                sample_real_rt(i,5) = mrm_rt_int(index_rt(mrm_rt),1);
                                sample_real_rt(i,7) = mrm_int;
                            else
                                sample_real_rt(i,5) = 0; %如果找到的保留时间下峰强度小于阈值，就赋值为0
                            end
                        end
                    end
                end
            end
            sample_real_rt = num2cell(sample_real_rt);
            sample_real_rt(:,6) = sample_calculation_rt(:,6);%compound name强度转移至file中
            
            eval(['xlswrite("result5\',sample_m,'_REAL_RT_NEG.xlsx",sample_real_rt);']); %TQMS检测到的离子数量
            end
        end
    end
end

clear BeginRow EndRow ans
clear delta_mz_tqms delta_rt file_id i j index index1 index2 index3 index4 index5 index_ion index_rt indexC int_threshold
clear mrm_int mrm_rt NameRow parent_product scanCount tempint tempMS temprt
clear sample_real_rt sample_real_name
                      
 T=toc;                        

 
 










    
    




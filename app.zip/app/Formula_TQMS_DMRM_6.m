%% part6 TQMS-dMRM数据处理，删除峰形不符合要求的离子对
tic
%% 提取复方、单味及其阴性样品的原始数据：1序号，2母离子，3保留时间，4峰高，5峰宽，6峰面积
%appreadexcel = "DGJZT_DMRM_formula_name_pos_neg.xlsx";
rawdata = table2cell(readtable(appreadexcel));%按模板整理每个复方的药味及路径信息，一次只放一个复方，正负离子模式分成两个表;原始数据命名时需标记pos和neg



% %% 修改文件名
% for i = 1:length(rawdata)
%     % 修改第2列
%     newStr2=split(rawdata(i,2),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr2(1,:) = [];
%     temp2 = strcat(pwd,newStr2);
%     rawdata(i,2) = temp2;
%     % 修改第3列
%     newStr3=split(rawdata(i,3),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr3(1,:) = [];
%     temp3 = strcat(pwd,newStr3);
%     if i==1
%         continue
%     else
%         rawdata(i,3) = temp3;
%     end
%     
%     % 修改第4列
%     newStr4=split(rawdata(i,4),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr4(1,:) = [];
%     temp4 = strcat(pwd,newStr4);
%     rawdata(i,4) = temp4;
%     % 修改第5列
%     newStr5=split(rawdata(i,5),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr5(1,:) = [];
%     temp5 = strcat(pwd,newStr5);
%     rawdata(i,5) = temp5;
%         % 修改第6列
%     newStr6=split(rawdata(i,6),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr6(1,:) = [];
%     temp6 = strcat(pwd,newStr6);
%     rawdata(i,6) = temp6;
%         % 修改第7列
%     newStr7=split(rawdata(i,7),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr7(1,:) = [];
%     temp7 = strcat(pwd,newStr7);
%     rawdata(i,7) = temp7;
% end
% 
% %% 再修改一下第一行第五列的东西
%     newStr51=split(rawdata(1,5),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr51(1,:) = [];
%     temp51 = strcat(pwd,newStr51);
%     rawdata(1,5) = temp51;
% %%=======================================

%% 创建一个存储处理结果的文件夹
if ~exist('result6','file')
    mkdir('result6')
end

Delta_RT =0.05;%min

%Height_shreshold = 100;
%Width_shreshold = 0.2;
%Area_shreshold = 300;%500,800,1000，SJ用500和1000筛选结果一样

delta_mz_tqms = 0.1;%Da

FORMULA_name = char(rawdata(1,1));


for m = 2:size(rawdata,1)
    for n = 1:2
        if n < 2
            FORMULA = [];
            FORMULA_rawdata = [];
            pathway_FORMULA = char(rawdata(1,2));%2,3,4;5,6,7是neg
            eval(['FORMULA = readtable("',pathway_FORMULA,'");']);
            
            FORMULA_file = FORMULA;
            FORMULA_file = [FORMULA_file.Cpd,FORMULA_file.Precursor,FORMULA_file.RT,FORMULA_file.Height,FORMULA_file.Width,FORMULA_file.Area];
            FORMULA_rawdata = FORMULA;%保留原始数据，后面用得上
            
            sample_m = char(rawdata(m,1));
            
            Sample = [];
            pathway_sample = char(rawdata(m,2));
            eval([sample_m,'_file = readtable("',pathway_sample,'");']); %读入
            eval(['Sample = ',sample_m,'_file;']);
            Sample = [Sample.Cpd,Sample.Precursor,Sample.RT,Sample.Height,Sample.Width,Sample.Area];
            
            Sample_control = [];
            pathway_control = char(rawdata(m,3));
            eval([sample_m,'_control_file = readtable("',pathway_control,'");']);
            eval(['Sample_control = ',sample_m,'_control_file;']);
            Sample_control = [Sample_control.Cpd,Sample_control.Precursor,Sample_control.RT,Sample_control.Height,Sample_control.Width,Sample_control.Area];
            
            Sample_rawdata = [];
            pathway_real_rt = char(rawdata(m,4));
            eval([sample_m,'_rt_file = readtable("',pathway_real_rt,'");']);
            eval(['Sample_rawdata = ',sample_m,'_rt_file;']);%补充ms2信息
            if  eval(['size(Sample_rawdata,2)<6'])
        eval(['fprintf("this species: ',sample_m,' has no charactor ions.\n");']);
        Sample_rawdata = table2cell(Sample_rawdata);
        eval(['xlswrite("result6\',sample_m,'_POS_dMRM_results.xlsx",Sample_rawdata);']);
            else
            if size(FORMULA_file,1) == size(Sample,1) & size(FORMULA_file,1) == size(Sample_control,1)
                for i = 1:size(FORMULA_file,1)%复方和单味中rt、峰高、峰宽、峰面积符合要求
                    index1 = find(FORMULA_file(i,3)-Sample(i,3)<=Delta_RT...%同一个方法跑出来的顺序相同，i共用
                        & FORMULA_file(i,4)>=Height_shreshold & Sample(i,4)>=Height_shreshold...
                        & FORMULA_file(i,5)>=Width_shreshold & Sample(i,5)>=Width_shreshold...
                        & FORMULA_file(i,6)>=Area_shreshold & Sample(i,6)>=Area_shreshold);
                    if isempty(index1)
                        FORMULA_file(i,7) = 0;
                        Sample(i,7) = 0;
                        Sample_control(i,7) = 0;
                    else
                        FORMULA_file(i,7) = 1;
                        Sample(i,7) = 1;
                        Sample_control(i,7) = 1;
                    end
                end
            else
                fprintf('Please check three files are matched!\n');
            end
            %%在复方和单味符合要求的离子中进一步选择阴性中峰高小于100或阴性峰高*20仍小于复方的离子
            for i = 1:size(FORMULA_file,1)
                if Sample_control(i,4)<= Height_shreshold
                    FORMULA_file(i,8) = 1;
                    Sample(i,8) = 1;
                    Sample_control(i,8) = 1;
                else
                    if Sample_control(i,4)*20 <= FORMULA_file(i,4)
                        FORMULA_file(i,8) = 1;
                        Sample(i,8) = 1;
                        Sample_control(i,8) = 1;
                    else
                        FORMULA_file(i,8) = 0;
                        Sample(i,8) = 0;
                        Sample_control(i,8) = 0;
                    end
                end
            end
            %%在复方、单味及阴性符合要求的离子中进一步选择阴性中峰面积小于1000或阴性峰面积*20仍小于复方的离子
            for i = 1:size(FORMULA_file,1)
                if Sample_control(i,6)<= Area_shreshold
                    FORMULA_file(i,9) = 1;
                    Sample(i,9) = 1;
                    Sample_control(i,9) = 1;
                else
                    if Sample_control(i,6)*20 <= FORMULA_file(i,6)
                        FORMULA_file(i,9) = 1;
                        Sample(i,9) = 1;
                        Sample_control(i,9) = 1;
                    else
                        FORMULA_file(i,9) = 0;
                        Sample(i,9) = 0;
                        Sample_control(i,9) = 0;
                    end
                end
            end
            %把化合物名字字符加进去
            FORMULA_rawdata = table2cell(FORMULA_rawdata);%table变成cell才能储存字符
            FORMULA_file = num2cell(FORMULA_file);%double变成cell才能储存字符
            FORMULA_file(:,10) = FORMULA_rawdata(:,2);%字符从原始数据中转移到bxxxt文件中
            
            FORMULA_7 = []; FORMULA_8 = []; FORMULA_9 = [];
            FORMULA_7 = cell2mat(FORMULA_file(:,7));%第7列提出来转成double才能索引
            index = find(FORMULA_7(:,1)==0);% 基于BXXXT_7的序号一定和BXXXT一样
            FORMULA_file(index,:) = [];
            
            FORMULA_8 = cell2mat(FORMULA_file(:,8));%第8列提出来转成double才能索引
            if size(FORMULA_8,1)>0
                index = find(FORMULA_8(:,1)==0);
                FORMULA_file(index,:) = [];
                FORMULA_file{1,11} = 0.01;
            else
                FORMULA_file{1,11} = 0.000001;
            end
            
            FORMULA_9 = cell2mat(FORMULA_file(:,9));%第9列提出来转成double才能索引
            if size(FORMULA_9,1)>0
                index = find(FORMULA_9(:,1)==0);
                FORMULA_file(index,:) = [];
                FORMULA_file{1,11} = 0.0001;
            else
                FORMULA_file{1,11} = 0.000001;
            end
            
            
            Sample_rawdata = table2cell(Sample_rawdata);
            Sample_MS2_name = Sample_rawdata(:,6);
            
            for i = 1:size(FORMULA_file,1)
                compound_name = char(FORMULA_file{i,10});
                eval(['index = find(contains(Sample_MS2_name(:,1),"',compound_name,'")==1);']); %real_rt中名字和dmrm复方样品（此时复方file中只剩下符合“有无有”要求的离子对）名称匹配上
                if isempty(index)%没有找到一样的名字，说明dMRM检测完为特征离子，有，
                    eval(['fprintf("check compound name in ',sample_m,'_file: line %d\n",i);']);
                    
                else
                    for j = 1:size(index,1)
                        index_ms2 = find(abs(FORMULA_file(i,2)- vpa(Sample_rawdata(index(j),1),2)) <= delta_mz_tqms);%母离子匹配
                        if isempty(index_ms2)
                            eval(['fprintf("check precusor ion in ',sample_m,'_file: line %d\n",i);']);
                        else
                            FORMULA_file(i,11) = Sample_rawdata(index(j),2);%子离子加进去
                        end
                    end
                end
            end
            
            eval(['xlswrite("result6\',sample_m,'_POS_dMRM_results.xlsx",FORMULA_file);']);
            end
        else
            FORMULA = [];
            FORMULA_rawdata = [];
            pathway_FORMULA = char(rawdata(1,5));%2,3,4;5,6,7
            eval(['FORMULA = readtable("',pathway_FORMULA,'");']);
            FORMULA_file = FORMULA;
            FORMULA_file = [FORMULA_file.Cpd,FORMULA_file.Precursor,FORMULA_file.RT,FORMULA_file.Height,FORMULA_file.Width,FORMULA_file.Area];
            FORMULA_rawdata = FORMULA;%保留原始数据，后面用得上
            
            sample_m = char(rawdata(m,1));
            
            Sample = [];
            pathway_sample = char(rawdata(m,5));
            eval([sample_m,'_file = readtable("',pathway_sample,'");']); %读入
            eval(['Sample = ',sample_m,'_file;']);
            Sample = [Sample.Cpd,Sample.Precursor,Sample.RT,Sample.Height,Sample.Width,Sample.Area];
            
            Sample_control = [];
            pathway_control = char(rawdata(m,6));
            eval([sample_m,'_control_file = readtable("',pathway_control,'");']);
            eval(['Sample_control = ',sample_m,'_control_file;']);
            Sample_control = [Sample_control.Cpd,Sample_control.Precursor,Sample_control.RT,Sample_control.Height,Sample_control.Width,Sample_control.Area];
            
            Sample_rawdata = [];
            pathway_real_rt = char(rawdata(m,7));
            eval([sample_m,'_rt_file = readtable("',pathway_real_rt,'");']);
            eval(['Sample_rawdata = ',sample_m,'_rt_file;']);%补充ms2信息
            if  eval(['size(Sample_rawdata,2)<6'])
        eval(['fprintf("this species: ',sample_m,'_neg has no charactor ions.\n");']);
        Sample_rawdata = table2cell(Sample_rawdata);
        eval(['xlswrite("result6\',sample_m,'_POS_dMRM_results.xlsx",Sample_rawdata);']);
            else
            if size(FORMULA_file,1) == size(Sample,1) & size(FORMULA_file,1) == size(Sample_control,1)
                for i = 1:size(FORMULA_file,1)%复方和单味中rt、峰高、峰宽、峰面积符合要求
                    index1 = find(FORMULA_file(i,3)-Sample(i,3)<=Delta_RT...%同一个方法跑出来的顺序相同，i共用
                        & FORMULA_file(i,4)>=Height_shreshold & Sample(i,4)>=Height_shreshold...
                        & FORMULA_file(i,5)>=Width_shreshold & Sample(i,5)>=Width_shreshold...
                        & FORMULA_file(i,6)>=Area_shreshold & Sample(i,6)>=Area_shreshold);
                    if isempty(index1)
                        FORMULA_file(i,7) = 0;
                        Sample(i,7) = 0;
                        Sample_control(i,7) = 0;
                    else
                        FORMULA_file(i,7) = 1;
                        Sample(i,7) = 1;
                        Sample_control(i,7) = 1;
                    end
                end
            else
                fprintf('Please check three files are matched!\n');
            end
            %%在复方和单味符合要求的离子中进一步选择阴性中峰高小于100或阴性峰高*20仍小于复方的离子
            for i = 1:size(FORMULA_file,1)
                if Sample_control(i,4)<= Height_shreshold
                    FORMULA_file(i,8) = 1;
                    Sample(i,8) = 1;
                    Sample_control(i,8) = 1;
                else
                    if Sample_control(i,4)*20 <= FORMULA_file(i,4)
                        FORMULA_file(i,8) = 1;
                        Sample(i,8) = 1;
                        Sample_control(i,8) = 1;
                    else
                        FORMULA_file(i,8) = 0;
                        Sample(i,8) = 0;
                        Sample_control(i,8) = 0;
                    end
                end
            end
            %%在复方、单味及阴性符合要求的离子中进一步选择阴性中峰面积小于1000或阴性峰面积*20仍小于复方的离子
            for i = 1:size(FORMULA_file,1)
                if Sample_control(i,6)<= Area_shreshold
                    FORMULA_file(i,9) = 1;
                    Sample(i,9) = 1;
                    Sample_control(i,9) = 1;
                else
                    if Sample_control(i,6)*20 <= FORMULA_file(i,6)
                        FORMULA_file(i,9) = 1;
                        Sample(i,9) = 1;
                        Sample_control(i,9) = 1;
                    else
                        FORMULA_file(i,9) = 0;
                        Sample(i,9) = 0;
                        Sample_control(i,9) = 0;
                    end
                end
            end
            %把化合物名字字符加进去
            FORMULA_rawdata = table2cell(FORMULA_rawdata);%table变成cell才能储存字符
            FORMULA_file = num2cell(FORMULA_file);%double变成cell才能储存字符
            FORMULA_file(:,10) = FORMULA_rawdata(:,2);%字符从原始数据中转移到bxxxt文件中
            
            FORMULA_7 = []; FORMULA_8 = []; FORMULA_9 = [];
            FORMULA_7 = cell2mat(FORMULA_file(:,7));%第7列提出来转成double才能索引
            index = find(FORMULA_7(:,1)==0);% 基于BXXXT_7的序号一定和BXXXT一样
            FORMULA_file(index,:) = [];
            
            FORMULA_8 = cell2mat(FORMULA_file(:,8));%第8列提出来转成double才能索引
            if size(FORMULA_8,1)>0
                index = find(FORMULA_8(:,1)==0);
                FORMULA_file(index,:) = [];
                FORMULA_file{1,11} = 0.0001;
            else
                FORMULA_file{1,11} = 0.000001;
            end
            
            FORMULA_9 = cell2mat(FORMULA_file(:,9));%第9列提出来转成double才能索引
            if size(FORMULA_9,1)>0
                index = find(FORMULA_9(:,1)==0);
                FORMULA_file(index,:) = [];
                FORMULA_file{1,11} = 0.0001;
            else
                FORMULA_file{1,11} = 0.000001;
            end
            
            
            Sample_rawdata = table2cell(Sample_rawdata);
            Sample_MS2_name = Sample_rawdata(:,6);
            
            for i = 1:size(FORMULA_file,1)
                compound_name = char(FORMULA_file{i,10});
                
                eval(['index = find(contains(Sample_MS2_name(:,1),"',compound_name,'")==1);']); %real_rt中名字和dmrm复方样品（此时复方file中只剩下符合“有无有”要求的离子对）名称匹配上
                if isempty(index)
                    eval(['fprintf("check compound name in ',sample_m,'_file_neg: line %d\n",i);']);  
                else
                    for j = 1:size(index,1)
                        index_ms2 = find(abs(FORMULA_file(i,2)- vpa(Sample_rawdata(index(j),1),2)) <= delta_mz_tqms);%母离子匹配
                        if isempty(index_ms2)
                            eval(['fprintf("check precusor ion in ',sample_m,'_file_neg: line %d\n",i);']); 
                        else
                            FORMULA_file(i,11) = Sample_rawdata(index(j),2);%子离子加进去
                        end
                    end
                end
            end
            
            eval(['xlswrite("result6\',sample_m,'_NEG_dMRM_results.xlsx",FORMULA_file);']);
            end
        end
    end
end

clear Delta_RT Height_shreshold Width_shreshold Area_shreshold index1 index2 i;
clear FORMULA_7 FORMULA_8 FORMULA_9 index Sample_MS2 Sample_MS2_name indexC j delta_mz_tqms index_ms2
clear sample_m rawdata pathway_sample pathway_real_rt pathway_FORMULA pathway_control n m FORMULA_name FORMULA compound_name

T=toc;


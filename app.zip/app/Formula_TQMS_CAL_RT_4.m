%% PART 3 保留时间TQMS-CAL-各个样品
tic
%% part 3.2，读取qc的保留时间和ms1
%读取原始数据
rawdata = table2cell(readtable(appreadexcel));%按模板整理每个复方的药味及路径信息，一次只放一个复方，正负离子模式分成两个表;原始数据命名时需标记pos和neg



%% 修改文件名
% for i = 1:length(rawdata)
%     % 修改第2列
%     newStr2=split(rawdata(i,2),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr2(1,:) = [];
%     temp2 = strcat(pwd,newStr2);
%     rawdata(i,2) = temp2;
%     % 修改第3列
%     newStr3=split(rawdata(i,3),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr3(1,:) = [];
%     temp3 = strcat(pwd,newStr3);
%     rawdata(i,3) = temp3;
% end

%%=======================================

%% 创建一个存储处理结果的文件夹
if ~exist('result4','file')
    mkdir('result4')
end

FORMULA = rawdata(:,[1,2]);
FORMULA_NEG = rawdata(:,[1,3]);
%% POS
%% 读取QC在高低分辨率仪器上的信息
pathway_qc_TQMS = char(FORMULA(1,2));
eval(['qc_TQMS = readtable("',pathway_qc_TQMS,'");']);%化合物序号；一级；保留时间；%读取qc在TQMS上的保留时间（由手动挑选而来，qqq上对着高分辨筛到的qc离子对，相互验证确定保留时间）
qc_TQMS = [qc_TQMS.Var1,qc_TQMS.Var2,qc_TQMS.Var3];

pathway_qc_HRMS = char(FORMULA(2,2));
eval(['qc_HRMS = readtable("',pathway_qc_HRMS,'");']);%需要和TQMS里的序号一致
qc_HRMS = [qc_HRMS.Var1,qc_HRMS.Var2,qc_HRMS.Var3,qc_HRMS.Var4];%化合物序号；一级；保留时间；一强二级
for i=1:size(qc_HRMS,1)
    delta_qc_rt = qc_TQMS(i,3) - qc_HRMS(i,3);
    qc_HRMS(i,6) = delta_qc_rt;
end

%%读取样品数据并计算
for m = 3:size(FORMULA,1)
    
    formula_name = char(FORMULA(m,1));
    pathway_POS = char(FORMULA(m,2));
    
    eval(['TCM_',formula_name,' = readtable("',pathway_POS,'");']);
    
    if eval(['size(TCM_',formula_name,')<6'])
        eval(['fprintf("this file: TCM_',formula_name,' is empty.\n");']);
        eval(['TCM_',formula_name,'=table2cell(TCM_',formula_name,');']);
        eval(['xlswrite(["result4\TCM_',formula_name,'_RT_CAL_TQMS_RESULTS_POS.xlsx"],TCM_',formula_name,');']);
    else
        sample_HRMS = [];
        eval(['sample_HRMS = [TCM_',formula_name,'.Var2,TCM_',formula_name,'.Var3,TCM_',formula_name,'.Var5,TCM_',formula_name,'.Var6];']);%MS1 保留时间 MS2 INT
        
        sample_TQMS = sample_HRMS;
        for i = 1:size(sample_HRMS,1)
            if sample_HRMS(i,2) < qc_HRMS(1,3) %对于样品中保留时间小于qc第一个点的化合物而言
                sample_TQMS(i,5) = sample_HRMS(i,2)+ qc_HRMS(1,6);
            elseif sample_HRMS(i,2) > qc_HRMS(length(qc_HRMS),3)  %对于样品中保留时间大于qc最后一个点的化合物而言
                sample_TQMS(i,5) = sample_HRMS(i,2)+ qc_HRMS(length(qc_HRMS),6);
            else
                index = find(qc_HRMS(:,3) > sample_HRMS(i,2)); %index 找到以后就是qc在高分辨中保留时间大于样品第i个点的序号，即t2的序号
                delta_qc_rt1 = qc_TQMS(min(index)-1,3)- qc_HRMS(min(index)-1,3); %min(index)就是刚好大于i的序号，min(index)-1就是刚好小于i保留时间的序号
                delta_qc_rt2 = qc_TQMS(min(index),3)- qc_HRMS(min(index),3);
                delta_sample_rt = delta_qc_rt1 + (delta_qc_rt2 - delta_qc_rt1)/(qc_HRMS(min(index),3)-qc_HRMS(min(index)-1,3))*(sample_HRMS(i,2)-qc_HRMS(min(index)-1,3));
                sample_TQMS(i,5) = sample_HRMS(i,2)+ delta_sample_rt;
            end
        end
        index = find(sample_TQMS(:,4)==0);
        eval(['TCM_',formula_name,' = table2cell(TCM_',formula_name,');']);%table 转成cell才能运算下一步：字符串转移
        eval(['TCM_',formula_name,'(index,:) = [];']);
        sample_TQMS = num2cell(sample_TQMS);
        sample_TQMS(index,:) = [];
        eval(['sample_TQMS(:,6) = TCM_',formula_name,'(:,1);']);%名称列转移到sample-tqms中
        if isempty(sample_TQMS)
            sample_TQMS{1,6} =0.000001;
            eval(['xlswrite(["result4\TCM_',formula_name,'_RT_CAL_TQMS_RESULTS_POS.xlsx"],sample_TQMS);']);
        else
            eval(['xlswrite(["result4\TCM_',formula_name,'_RT_CAL_TQMS_RESULTS_POS.xlsx"],sample_TQMS);']);
        end
    end
end
clear m

%% NEG
%% 读取QC在高低分辨率仪器上的信息

pathway_qc_TQMS_NEG = char(FORMULA_NEG(1,2));
eval(['qc_TQMS_NEG = readtable("',pathway_qc_TQMS_NEG,'");']);%化合物序号；一级；保留时间；%读取qc在TQMS上的保留时间（由手动挑选而来，qqq上对着高分辨筛到的qc离子对，相互验证确定保留时间）
qc_TQMS_NEG = [qc_TQMS_NEG.Var1,qc_TQMS_NEG.Var2,qc_TQMS_NEG.Var3];

pathway_qc_HRMS_NEG = char(FORMULA_NEG(2,2));
eval(['qc_HRMS_NEG = readtable("',pathway_qc_HRMS_NEG,'");']);%需要和TQMS里的序号一致
qc_HRMS_NEG = [qc_HRMS_NEG.Var1,qc_HRMS_NEG.Var2,qc_HRMS_NEG.Var3,qc_HRMS_NEG.Var4];%化合物序号；一级；保留时间；一强二级
%%读取样品数据并计算
for i=1:size(qc_HRMS_NEG,1)
    delta_qc_rt = qc_TQMS_NEG(i,3) - qc_HRMS_NEG(i,3);%要确保qc-tqms和qc-hrms顺序一致
    qc_HRMS_NEG(i,6) = delta_qc_rt;
end
    
for m = 3:size(FORMULA_NEG,1)
    formula_name_NEG = char(FORMULA_NEG(m,1));
    pathway_NEG = char(FORMULA_NEG(m,2));

    eval(['TCM_',formula_name_NEG,'_NEG = readtable("',pathway_NEG,'");']);
    if eval(['size(TCM_',formula_name_NEG,'_NEG,2)<6'])
        eval(['fprintf("this file: TCM_',formula_name_NEG,'_NEG is empty.\n");']);
        eval(['TCM_',formula_name_NEG,'=table2cell(TCM_',formula_name_NEG,');']);
        eval(['xlswrite(["result4\TCM_',formula_name_NEG,'_RT_CAL_TQMS_RESULTS_NEG.xlsx"],TCM_',formula_name_NEG,');']);
    else
        sample_HRMS_NEG = [];
        eval(['sample_HRMS_NEG = [TCM_',formula_name_NEG,'_NEG.Var2,TCM_',formula_name_NEG,'_NEG.Var3,TCM_',formula_name_NEG,'_NEG.Var5,TCM_',formula_name_NEG,'_NEG.Var6];']);%MS1 保留时间 MS2 INT

        sample_TQMS_NEG = sample_HRMS_NEG;
        for i = 1:size(sample_HRMS_NEG,1)
            if sample_HRMS_NEG(i,2) < qc_HRMS_NEG(1,3) %对于样品中保留时间小于qc第一个点的化合物而言
                sample_TQMS_NEG(i,5) = sample_HRMS_NEG(i,2)+ qc_HRMS_NEG(1,6);
            elseif sample_HRMS_NEG(i,2) > qc_HRMS_NEG(length(qc_HRMS_NEG),3)  %对于样品中保留时间大于qc最后一个点的化合物而言
                sample_TQMS_NEG(i,5) = sample_HRMS_NEG(i,2)+ qc_HRMS_NEG(length(qc_HRMS_NEG),6);
            else
                index = find(qc_HRMS_NEG(:,3) > sample_HRMS_NEG(i,2)); %index 找到以后就是qc在高分辨中保留时间大于样品第i个点的序号，即t2的序号
                delta_qc_rt1 = qc_TQMS_NEG(min(index)-1,3)- qc_HRMS_NEG(min(index)-1,3); %min(index)就是刚好大于i的序号，min(index)-1就是刚好小于i保留时间的序号
                delta_qc_rt2 = qc_TQMS_NEG(min(index),3)- qc_HRMS_NEG(min(index),3);
                delta_sample_rt = delta_qc_rt1 + (delta_qc_rt2 - delta_qc_rt1)/(qc_HRMS_NEG(min(index),3)-qc_HRMS_NEG(min(index)-1,3))*(sample_HRMS_NEG(i,2)-qc_HRMS_NEG(min(index)-1,3));
                sample_TQMS_NEG(i,5) = sample_HRMS_NEG(i,2)+ delta_sample_rt;
            end
        end
        index = find(sample_TQMS_NEG(:,4)==0);
        %eval(['TCM_',formula_name_NEG,'_NEG = {}']);
        eval(['TCM_',formula_name_NEG,'_NEG = table2cell(TCM_',formula_name_NEG,'_NEG);']);%table 转成cell才能运算下一步：字符串转移
        eval(['TCM_',formula_name_NEG,'_NEG(index,:) = [];']);
        sample_TQMS_NEG = num2cell(sample_TQMS_NEG);
        sample_TQMS_NEG(index,:) = [];
        eval(['sample_TQMS_NEG(:,6) = TCM_',formula_name_NEG,'_NEG(:,1);']);%名称列转移到sample-tqms中
        if isempty(sample_TQMS_NEG)
            sample_TQMS_NEG{1,6} =0.000001;
            eval(['xlswrite(["result4\TCM_',formula_name_NEG,'_RT_CAL_TQMS_RESULTS_NEG.xlsx"],sample_TQMS_NEG);']);
        else
            eval(['xlswrite(["result4\TCM_',formula_name_NEG,'_RT_CAL_TQMS_RESULTS_NEG.xlsx"],sample_TQMS_NEG);']);
        end
    end
end
    
clear delta_mz delta_qc_rt delta_qc_rt1 delta_qc_rt2 delta_sample_rt i index index1 indexd indexi indexj j MS1 ms2i
clear MSP_Commenti mzi sample top1_abs top1_index top1_ms2 delta_rt qc rti MSP_rt_mz        
clear formula_name formula_name_NEG m pathway_NEG pathway_POS pathway_qc_HRMS pathway_qc_HRMS_NEG pathway_qc_TQMS pathway_qc_TQMS_NEG
   

T=toc;



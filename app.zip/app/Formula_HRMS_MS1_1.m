%% part1 筛每个药味一级特征母离子
tic
%% 需要输入7个单味药，复方，blank的.csv文件；输出结果为特征一级母离子ms1-results.xslx



% 第一步记录posneg的绝对位置   在app界面里面读取到的filepath给到excel_pos
% 然后在代码里面把excel_pos这一行给注释掉。
% excel_pos = "DGJZT_MS1_formula_name_pos_neg.xlsx";


rawdata = table2cell(readtable(appreadexcel));%按模板整理每个复方的药味及路径信息，一次只放一个复方，正负离子模式分成两列;原始数据命名时需标记pos和neg


%% 修改文件名
% for i = 1:length(rawdata)
%     % 修改第2列
%     newStr2=split(rawdata(i,2),'C:\Users\z820\Desktop\lxl-bxxxt\20230225-7f-pos-neg\DGJZT\+\MS1');
%     newStr2(1,:) = [];
%     temp2 = strcat(pwd,newStr2);
%     rawdata(i,2) = temp2;
%     % 修改第3列
%     newStr3=split(rawdata(i,3),'C:\Users\z820\Desktop\lxl-bxxxt\20230225-7f-pos-neg\DGJZT\-\MS1');
%     newStr3(1,:) = [];
%     temp3 = strcat(pwd,newStr3);
%     rawdata(i,3) = temp3;
% end

%%=======================================

%% 创建一个存储处理结果的文件夹
if ~exist('result1','file')
    mkdir('result1')
end
pathname = string(strcat(pwd,'\result1'));%保存的地方

%% 
FORMULA = rawdata(:,[1,2]);
FORMULA_neg = rawdata(:,[1,3]);
rt1 = 0.5;%%去除前0.5min
rt2 = 16;%%去除后4min
% delat_RT = 0.1; %% min%设置mz与RT的匹配误差
% delat_MZ = 10; %% ppm

Formula_name = char(FORMULA(2,1));
Formula_name_neg = char(FORMULA_neg(2,1));
for m = 1:size(FORMULA,1)
    sample_m = char(FORMULA(m,1));
    pathway_m = char(FORMULA(m,2));
    eval(['TCM_',sample_m,' = readtable("',pathway_m,'");']); %读入
    eval(['TCM_',sample_m,' = [TCM_',sample_m,'.Var3, TCM_',sample_m,'.Var5, TCM_',sample_m,'.NormalisedAbundance];']);%提取ms1、rt和int
    eval(['TCM_',sample_m,'(TCM_',sample_m,'(:,2)<rt1,:) = [];']);%删首尾无效保留时间段
    eval(['TCM_',sample_m,'(TCM_',sample_m,'(:,2)>rt2,:) = [];']);
    eval(['TCM_',sample_m,' = distinct(TCM_',sample_m,',delat_RT,delat_MZ);']);%自身去重
end
for m = 1:size(FORMULA_neg,1)
    sample_m = char(FORMULA_neg(m,1));
    pathway_m = char(FORMULA_neg(m,2));
    eval(['TCM_',sample_m,'_neg = readtable("',pathway_m,'");']);
    eval(['TCM_',sample_m,'_neg = [TCM_',sample_m,'_neg.Var3, TCM_',sample_m,'_neg.Var5, TCM_',sample_m,'_neg.NormalisedAbundance];']);
    eval(['TCM_',sample_m,'_neg(TCM_',sample_m,'_neg(:,2)<rt1,:) = [];']);
    eval(['TCM_',sample_m,'_neg(TCM_',sample_m,'_neg(:,2)>rt2,:) = [];']);
    eval(['TCM_',sample_m,'_neg = distinct(TCM_',sample_m,'_neg,delat_RT,delat_MZ);']);
end

% delat_RT = 0.15; %% min
% delat_MZ = 20; % ppm
for m = 3:size(FORMULA,1)%第1、2行为blank和复方，必须从第3行开始循环
    for n = 1:2
        if n<2%正模式
            TCM_formula_file = []; TCM_Taget_file = [];TCM_control_file = [];
            eval(['TCM_formula_file = TCM_',Formula_name,';']);%定义复方
            TCM_Taget = char(FORMULA(m,1));%m从第3行开始，定义目标单味药
            eval(['TCM_Taget_file = TCM_',TCM_Taget,';']);%在工作区找到目标单味药的文件
            TCM_composition = FORMULA(1:end,1);
            TCM_composition([1:2,m],:) = [];%删除目标药味，便于后面将其余药味合并成阴性
            TCM_control_file = [];%先定义一个空文档
            
            for k = 1:size(TCM_composition,1)
                eval(['TCM_Control_k = TCM_',char(TCM_composition(k)),';']);
                TCM_control_file = [TCM_control_file;TCM_Control_k];%合并目标药味以外的药味，作为阴性样品，%按列合并用分号；
            end
            
            for i = 1:size(TCM_formula_file,1)%单味和复方匹配
                MZ_formula = TCM_formula_file(i,1); %复方中第i个质荷比
                RT_formula = TCM_formula_file(i,2);  %复方中第i个保留时间
                index_formula = find(abs(MZ_formula-TCM_Taget_file(:,1))/MZ_formula*1000000 <= delat_MZ & abs(RT_formula-TCM_Taget_file(:,2)) <= delat_RT);
                if isempty(index_formula)
                    TCM_formula_file(i,4) = 0;%复方中的离子没和单味中匹配上,第四列为0
                    TCM_formula_file(i,5) = 0;%第五列为匹配上的个数，0个
                elseif size(index_formula,1)==1
                    TCM_formula_file(i,4) = 1;%复方中的离子与单味中匹配上1个，第四列为1
                    TCM_formula_file(i,5) = 1;%第五列为匹配上的个数，1个
                    TCM_formula_file(i,6) = TCM_Taget_file(index_formula,2);%第六列返回和单味里匹配上的保留时间
                else
                    TCM_formula_file(i,4) = 1;%复方中的离子与单味中匹配上了多个，第四列为1
                    TCM_formula_file(i,5) = size(index_formula,1);  %第五列返回匹配上的个数
                    TCM_formula_file(i,6) = mean(TCM_Taget_file(index_formula,2));%返回匹配上多个离子保留时间的平均值
                end
            end
            TCM_formula_file(TCM_formula_file(:,4)==0,:)=[];%删除复方中第四列标记为0的数据，只保留复方与单味中匹配上的离子
            
            for i = 1:size(TCM_formula_file,1)%单味与复方匹配完后再和阴性匹配
                MZ_formula = TCM_formula_file(i,1);  %单味中第i个质荷比
                RT_formula = TCM_formula_file(i,2);  %单味中第i个保留时间
                Abundance = TCM_formula_file(i,3);
                index_control = find(abs(MZ_formula-TCM_control_file(:,1))/MZ_formula*1000000 <= delat_MZ & abs(RT_formula-TCM_control_file(:,2)) <= delat_RT);
                if isempty(index_control)
                    TCM_formula_file(i,7) = 1; %复方中的离子与阴性没有匹配上，即第一类特征离子，第七列返回1
                    TCM_formula_file(i,8) = 0;
                    TCM_formula_file(i,9) = 0;
                elseif size(index_control,1)==1  %如果在阴性样本中只匹配上一次
                    TCM_formula_file(i,7) = 2;
                    TCM_formula_file(i,8) = TCM_control_file(index_control,3); %匹配上一次后返回阴性中的强度
                    TCM_formula_file(i,9) = Abundance/TCM_formula_file(i,8);%匹配上一次后返回复方与阴性强度的比值
                else
                    TCM_formula_file(i,7) = 2;
                    TCM_formula_file(i,8) = max(TCM_control_file(index_control,3)); %匹配上一次后返回阴性中的强度
                    TCM_formula_file(i,9) = Abundance/TCM_formula_file(i,8);%匹配上一次后返回复方与阴性强度的比值
                end
            end
            TCM_formula_file((0<TCM_formula_file(:,9)&TCM_formula_file(:,9)<20),:)=[]; %保留第9列标记为0的数据，以及第9列大于20倍的离子
            if isempty(TCM_formula_file)
                TCM_formula_file = 0;
                eval(['xlswrite(["result1\TCM_',TCM_Taget,'_POS_ms1_results.xlsx"],TCM_formula_file)']);
            else
                eval(['xlswrite(["result1\TCM_',TCM_Taget,'_POS_ms1_results.xlsx"],TCM_formula_file)']);
            end
            
        else%n=2，负离子模式
            TCM_formula_file_neg = []; TCM_Taget_file_neg = [];TCM_control_file_neg = [];
            eval(['TCM_formula_file_neg = TCM_',Formula_name_neg,'_neg;']);
            TCM_Taget_neg = char(FORMULA_neg(m,1));%m从第3行开始
            eval(['TCM_Taget_file_neg = TCM_',TCM_Taget_neg,'_neg;']);
            TCM_composition_neg = FORMULA_neg(1:end,1);
            TCM_composition_neg([1:2,m],:) = [];%删除目标药味，便于后面将其余药味合并成阴性
            TCM_control_file_neg = [];%先定义一个空文档
            
            for k = 1:size(TCM_composition_neg,1)
                eval(['TCM_Control_k = TCM_',char(TCM_composition_neg(k)),'_neg;']);
                TCM_control_file_neg = [TCM_control_file_neg;TCM_Control_k];%按列合并用分号；
            end
            
            for i = 1:size(TCM_formula_file_neg,1)%单味和复方匹配
                MZ_formula = TCM_formula_file_neg(i,1); %复方中第i个质荷比
                RT_formula = TCM_formula_file_neg(i,2);  %复方中第i个保留时间
                index_formula = find(abs(MZ_formula-TCM_Taget_file_neg(:,1))/MZ_formula*1000000 <= delat_MZ & abs(RT_formula-TCM_Taget_file_neg(:,2)) <= delat_RT);
                if isempty(index_formula)
                    TCM_formula_file_neg(i,4) = 0;%复方中的离子没和单味中匹配上,第四列为0
                    TCM_formula_file_neg(i,5) = 0;%第五列为匹配上的个数，0个
                elseif size(index_formula,1)==1
                    TCM_formula_file_neg(i,4) = 1;%复方中的离子与单味中匹配上1个，第四列为1
                    TCM_formula_file_neg(i,5) = 1;%第五列为匹配上的个数，1个
                    TCM_formula_file_neg(i,6) = TCM_Taget_file_neg(index_formula,2);%第六列返回和单味里匹配上的保留时间
                else
                    TCM_formula_file_neg(i,4) = 1;%复方中的离子与单味中匹配上了多个，第四列为1
                    TCM_formula_file_neg(i,5) = size(index_formula,1);  %第五列返回匹配上的个数
                    TCM_formula_file_neg(i,6) = mean(TCM_Taget_file_neg(index_formula,2));%返回匹配上多个离子保留时间的平均值
                end
            end
            TCM_formula_file_neg(TCM_formula_file_neg(:,4)==0,:)=[];%删除复方中第四列标记为0的数据，只保留复方与单味中匹配上的离子
            
            for i = 1:size(TCM_formula_file_neg,1)
                MZ_formula = TCM_formula_file_neg(i,1);  %单味中第i个质荷比
                RT_formula = TCM_formula_file_neg(i,2);  %单味中第i个保留时间
                Abundance = TCM_formula_file_neg(i,3);
                index_control = find(abs(MZ_formula-TCM_control_file_neg(:,1))/MZ_formula*1000000 <= delat_MZ & abs(RT_formula-TCM_control_file_neg(:,2)) <= delat_RT);
                if isempty(index_control)
                    TCM_formula_file_neg(i,7) = 1; %复方中的离子与阴性没有匹配上，即第一类特征离子，第七列返回1
                    TCM_formula_file_neg(i,8) = 0;
                    TCM_formula_file_neg(i,9) = 0;
                elseif size(index_control,1)==1  %如果在阴性样本中只匹配上一次
                    TCM_formula_file_neg(i,7) = 2;
                    TCM_formula_file_neg(i,8) = TCM_control_file_neg(index_control,3); %匹配上一次后返回阴性中的强度
                    TCM_formula_file_neg(i,9) = Abundance/TCM_formula_file_neg(i,8);%匹配上一次后返回复方与阴性强度的比值
                else
                    TCM_formula_file_neg(i,7) = 2;
                    TCM_formula_file_neg(i,8) = max(TCM_control_file_neg(index_control,3)); %匹配上一次后返回阴性中的强度
                    TCM_formula_file_neg(i,9) = Abundance/TCM_formula_file_neg(i,8);%匹配上一次后返回复方与阴性强度的比值
                end
            end
            TCM_formula_file_neg((0<TCM_formula_file_neg(:,9)&TCM_formula_file_neg(:,9)<20),:)=[];%保留DATA第9列标记为0的数据，以及第9列大于20倍的离子
            if isempty(TCM_formula_file_neg)
                TCM_formula_file_neg = 0;
                
                eval(['xlswrite(["result1\TCM_',TCM_Taget_neg,'_NEG_ms1_results.xlsx"],TCM_formula_file_neg)']);
            else
                eval(['xlswrite(["result1\TCM_',TCM_Taget_neg,'_NEG_ms1_results.xlsx"],TCM_formula_file_neg)']);%0630修改
            end
        end
    end
end

clear Abundance delat_MZ delat_RT i index_control index_formula m MZ_formula n pathway_m rt1 rt2 RT_formula sample_m k Formula_name
clear TCM_Control_k TCM_Taget TCM_Taget_file TCM_Taget_file_neg TCM_Taget_neg
T=toc;


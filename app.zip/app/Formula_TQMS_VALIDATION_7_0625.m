%% part 6 多药味同时判别
tic
%% 创建一个存储处理结果的文件夹
if ~exist('result7','file')
    mkdir('result7')
end



%% pos-提取检测样品的原始数据：1序号，2名称，3母离子，4保留时间，5峰高，6峰宽，7峰面积
%rawdata = table2cell(readtable(appreadexcel));

% sample = readtable("0403-DGJZT-3-POS.csv");
% sample_neg = readtable("0403-DGJZT-3-NEG.csv");
%  appreaderexcel7_1="0403-DGJZT-3-POS.csv";
%  appreaderexcel7_2="0403-DGJZT-3-NEG.csv";

sample = readtable(appreaderexcel7_1);
sample_neg = readtable(appreaderexcel7_2);

% standard =  readtable("0401-DPC2-7F-FILT2-REFERENCE-POS.csv");
% standard_neg =  readtable("0401-DPC2-7F-FILT2-REFERENCE-NEG.csv");
%app.filepath73 = "C:\Users\z820\Desktop\lxl-bxxxt\20230619-app\0506-lxl\DGJZT\E7\0401-DPC2-7F-FILT2-REFERENCE-POS.csv";
%appreaderexcel7_3 = app.filepath73;           
standard =  readtable(appreaderexcel7_3);
standard_neg =  readtable(appreaderexcel7_4);
% 

Cpd = num2cell(sample.Cpd);
Name = sample.Name;
Precursor = num2cell(sample.Precursor);
RT = num2cell(sample.RT);
Height = num2cell(sample.Height);
Width = num2cell(sample.Width);
Area = num2cell(sample.Area);

Cpd_neg = num2cell(sample_neg.Cpd);
Name_neg = sample_neg.Name;
Precursor_neg = num2cell(sample_neg.Precursor);
RT_neg = num2cell(sample_neg.RT);
Height_neg = num2cell(sample_neg.Height);
Width_neg = num2cell(sample_neg.Width);
Area_neg = num2cell(sample_neg.Area);

Cpd_standard = num2cell(standard.Cpd);
Name_standard = standard.Name;
Precursor_standard = num2cell(standard.Precursor);
RT_standard = num2cell(standard.RT);
Product_standard = num2cell(standard.ProductIon);

Cpd_standard_neg = num2cell(standard_neg.Cpd);
Name_standard_neg = standard_neg.Name;
Precursor_standard_neg = num2cell(standard_neg.Precursor);
RT_standard_neg = num2cell(standard_neg.RT);
Product_standard_neg = num2cell(standard_neg.ProductIon);

sample = [Cpd,Name,Precursor,RT,Height,Width,Area];
sample_neg = [Cpd_neg,Name_neg,Precursor_neg,RT_neg,Height_neg,Width_neg,Area_neg];
standard = [Cpd_standard,Name_standard,Precursor_standard,RT_standard,Product_standard];
standard_neg = [Cpd_standard_neg,Name_standard_neg,Precursor_standard_neg,RT_standard_neg,Product_standard_neg];

clear Cpd Name Precursor RT Height Width Area Cpd_neg Name_neg Precursor_neg RT_neg Height_neg Width_neg Area_neg
clear Cpd_standard Name_standard Precursor_standard RT_standard standard_ Cpd_standard_neg Name_standard_neg Precursor_standard_neg RT_standard_neg Product_standard_neg

delta_rt = 0.25;%min 0.1   
% Height_shreshold = 80;%100%0625修改，被注释掉
% Width_shreshold = 0.12;
% Area_shreshold = 800;%正式鉴定时可800,500,300
%match_shreshold = 0.5;%匹配到75%以上的离子对,0.65

%FORMULA = table2cell(readtable("7F-formula name.xlsx"));%复方的数量不确定，可能为5，为8，为100
FORMULA = table2cell(readtable(appreaderexcel7_5));%复方的数量不确定，可能为5，为8，为100

str_m="";
for f = 1:size(FORMULA,1)
    total_singFormuNum = []; total_match_number = [];
    total_match_number_neg = []; total_singFormuNum_neg = [];
    total = [];match_species_num = [];
    formula_name = char(FORMULA(f,1));
    formula_compos = FORMULA(f,2:end);
    formula_compos(cellfun(@isempty,formula_compos)) = [];
    for m = 1:size(formula_compos,2)
        sample_m = char(formula_compos(m));
        for n = 1:2
            if n < 2
                %pos鉴定
                %从sample和standard中提取只含有第m个药味的离子对信息
                index_sample = []; TCM_sample = []; TCM_standard =[];
                eval(['index_sample = find(contains(sample(:,2),"',sample_m,'")==1);']);%找到样品名字里含有索引字符的离子对的行号
                TCM_sample = sample(index_sample,:);%成功把样品中检测到的大枣离子对信息提取出来
                eval(['index_standard = find(contains(standard(:,2),"',sample_m,'")==1);']);%找到参照表名字里含有索引字符的离子对的行号
                TCM_standard = standard(index_standard,:);%成功把样品中检测到的大枣离子对信息提取出来
                
                TCM_name_sample = []; TCM_name_standard = [];
                TCM_name_sample = TCM_sample(:,2);%名称以字符串格式单独提取出来；%cellstr(standard(:,2));
                TCM_name_standard = TCM_standard(:,2);
                TCM_sample(:,2) = [];%删掉字符串列以后才好转化成matrx
                TCM_sample = cell2mat(TCM_sample);%cell转化成matrix便于运算：标记0和1
                TCM_standard(:,2) = [];
                TCM_standard = cell2mat(TCM_standard);
                
                for i = 1:size(TCM_sample,1)
                    index1 = find(strcmp(TCM_name_standard(:,1),TCM_name_sample(i,1)));%字符串匹配
                    if isempty(index1)
                        TCM_sample(i,7) = 0;%没找到就说明没有采集参照里的离子对
                    else%sample和standard名字对上了
                        index2 = find(TCM_standard(index1,3)-TCM_sample(i,3)<=delta_rt & ...
                            TCM_sample(i,4)>Height_shreshold & ...
                            TCM_sample(i,5)>Width_shreshold & ...
                            TCM_sample(i,6)>Area_shreshold, 1);
                        if isempty(index2)%没有找到，说明不符合设置的阈值条件
                            TCM_sample(i,7) = 1;
                            TCM_sample(i,10) = TCM_standard(index1,2);%standard precusor m/z
                            TCM_sample(i,11) = TCM_standard(index1,3);%standard rt
                            TCM_sample(i,12) = TCM_standard(index1,4);%standard preduct m/z
                        else
                            TCM_sample(i,7) = 2;%标记为2说明这个离子对符合条件，说明样品里面有这个化合物
                            TCM_sample(i,10) = TCM_standard(index1,2);%standard precusor m/z
                            TCM_sample(i,11) = TCM_standard(index1,3);%standard rt 
                            TCM_sample(i,12) = TCM_standard(index1,4);%standard preduct m/z
                        end
                    end
                end
                if isempty(TCM_sample)
                    eval(['match_num_',sample_m,' = 0.000001;']);
                    eval([sample_m,'_size = size(TCM_standard,1);']);
                    eval(['match_rate_',sample_m,' = 0.00000001;']);
                    eval(['fprintf("please check the compound name:',sample_m,' in sample file.\n");']);
                else
                    eval(['match_num_',sample_m,' = length(find(TCM_sample(:,7)==2));']);
                    eval([sample_m,'_size = size(TCM_standard,1);']);
                    eval(['match_rate_',sample_m,' = match_num_',sample_m,'/',sample_m,'_size;']);
                    eval(['TCM_sample(1,9) = match_rate_',sample_m,';']);%必须第九行数字先读入
                    TCM_sample = num2cell(TCM_sample);
                    TCM_sample(:,8) = TCM_name_sample(:,1);%第八行输入文本
%                     eval(['xlswrite("result\',sample_m,'_pos_match_results.xlsx",TCM_sample);']);
                end
                eval(['total_match_number(m,1) = match_num_',sample_m,';']);%每味药匹配数量汇总
                eval(['total_singFormuNum(m,1) = ',sample_m,'_size;']);%每味药理论匹配数汇总
            else
                %%neg鉴定
                index_sample_neg =[]; index_standard_neg =[]; TCM_sample_neg =[]; TCM_standard_neg =[]; TCM_name_sample_neg =[]; TCM_name_standard_neg =[];
                eval(['index_sample_neg = find(contains(sample_neg(:,2),"',sample_m,'")==1);']);%找到样品名字里含有索引字符的离子对的行号
                TCM_sample_neg = sample_neg(index_sample_neg,:);%成功把样品中检测到的大枣离子对信息提取出来
                
                eval(['index_standard_neg = find(contains(standard_neg(:,2),"',sample_m,'")==1);']);%找到参照表名字里含有索引字符的离子对的行号
                TCM_standard_neg = standard_neg(index_standard_neg,:);%成功把样品中检测到的大枣离子对信息提取出来
                
                TCM_name_sample_neg = TCM_sample_neg(:,2);%名称以字符串格式单独提取出来；%cellstr(standard(:,2));
                TCM_name_standard_neg = TCM_standard_neg(:,2);
                
                TCM_sample_neg(:,2) = [];%删掉字符串列以后才好转化成matrx
                TCM_sample_neg = cell2mat(TCM_sample_neg);%cell转化成matrix便于运算：标记0和1
                TCM_standard_neg(:,2) = [];
                TCM_standard_neg = cell2mat(TCM_standard_neg);
                for i = 1:size(TCM_sample_neg,1)
                    index1 = find(strcmp(TCM_name_standard_neg(:,1),TCM_name_sample_neg(i,1)));%字符串匹配
                    if isempty(index1)
                        TCM_sample_neg(i,7) = 0;%没找到就说明没有采集参照里的离子对
                    else%sample和standard名字对上了
                        index2 = find(TCM_standard_neg(index1,3)-TCM_sample_neg(i,3)<=delta_rt & ...
                            TCM_sample_neg(i,4)>Height_shreshold & ...
                            TCM_sample_neg(i,5)>Width_shreshold & ...
                            TCM_sample_neg(i,6)>Area_shreshold, 1);
                        if isempty(index2)%没有找到，说明不符合设置的阈值条件
                            TCM_sample_neg(i,7) = 1;
                            TCM_sample_neg(i,10) = TCM_standard_neg(index1,2);%standard precusor m/z
                            TCM_sample_neg(i,11) = TCM_standard_neg(index1,3);%standard rt
                            TCM_sample_neg(i,12) = TCM_standard_neg(index1,4);%standard product m/z
                        else
                            TCM_sample_neg(i,7) = 2;%标记为2说明这个离子对符合条件，说明样品里面有这个化合物
                            %TCM_sample_neg(i,10) = TCM_name_standard_neg(index1(index2),?);
                            TCM_sample_neg(i,10) = TCM_standard_neg(index1,2);%standard precusor m/z
                            TCM_sample_neg(i,11) = TCM_standard_neg(index1,3);%standard rt 
                            TCM_sample_neg(i,12) = TCM_standard_neg(index1,4);%standard product m/z
                        end
                    end
                end
                if isempty(TCM_sample_neg)
                    eval(['match_num_',sample_m,'_neg = 0.000001;']);%eval(['match_num_',sample_m,'_neg = [];']);
                    eval([sample_m,'_neg_size = size(TCM_standard_neg,1);']);
                    eval(['match_rate_',sample_m,'_neg = 0.00000001;']);%eval(['match_rate_',sample_m,'_neg = 0;']);
                    eval(['fprintf("please check the compound name:',sample_m,' in sample_neg file.\n");']);
                    eval(['total_match_number_neg(m,1) = match_num_',sample_m,'_neg;']);
                    eval(['total_singFormuNum_neg(m,1) = ',sample_m,'_neg_size;']);%每味药理论匹配离子数汇总
                else
                    eval(['match_num_',sample_m,'_neg = length(find(TCM_sample_neg(:,7)==2));']);
                    eval([sample_m,'_neg_size = size(TCM_standard_neg,1);']);
                    eval(['match_rate_',sample_m,'_neg = match_num_',sample_m,'_neg/',sample_m,'_neg_size;']);
                    eval(['TCM_sample_neg(1,9) = match_rate_',sample_m,'_neg;']);%必须第九行数字先读入
                    TCM_sample_neg = num2cell(TCM_sample_neg);
                    TCM_sample_neg(:,8) = TCM_name_sample_neg(:,1);%第八行输入文本
                    %eval(['xlswrite("',sample_m,'_neg_match_results.xlsx",TCM_sample_neg);']);
                    TCM_sample_total = [TCM_sample;TCM_sample_neg];
                    eval(['xlswrite("result7\',sample_m,'_pos_neg_match_results.xlsx",TCM_sample_total);']);%0630修改
                    eval(['total_match_number_neg(m,1) = match_num_',sample_m,'_neg;']);
                    eval(['total_singFormuNum_neg(m,1) = ',sample_m,'_neg_size;']);%每味药理论匹配离子数汇总
                end
            end
        end
        %根据正负离子模式的计算结果判断第f个复方中是否含有第m个药味%0625修改str
        eval(['match_rate_',sample_m,'_total = (match_num_',sample_m,'+match_num_',sample_m,'_neg)/(',sample_m,'_size+',sample_m,'_neg_size);']);
        if  eval(['match_rate_',sample_m,'_total >= match_shreshold+0.1 & match_rate_',sample_m,'_total <= 100'])%match_rate_BXXXT_DZ_total >= match_shreshold
            %eval(['match_rate_',sample_m,'_total >= match_shreshold'])
            str1= eval(['sprintf("Have: ',sample_m,', P: %.0f , ",',sample_m,'_size);']);
            str2= eval(['sprintf("Match:%.0f ; ",match_num_',sample_m,');']);
            str3= eval(['sprintf("N: %.0f , ",',sample_m,'_neg_size);']);
            str4= eval(['sprintf("Match:%.0f ; ",match_num_',sample_m,'_neg);']);
            str5= eval(['sprintf("Gross Match: %.2f\n",match_rate_',sample_m,'_total);']);%0626修改
            eval(['total(m,1) = match_rate_',sample_m,'_total;']);
            eval(['match_species_num(m,1) = match_rate_',sample_m,'_total;']);
           % str = [str1,str2,str3,str4,str5];
           str = str1+str2+str3+str4+str5;
        elseif eval(['match_rate_',sample_m,'_total >= match_shreshold  & match_rate_',sample_m,'_total < match_shreshold+0.1'])
            str1=eval(['sprintf("May Have: ',sample_m,', P: %.0f , ",',sample_m,'_size);']);
            str2=eval(['sprintf("Match:%.0f ; ",match_num_',sample_m,');']);
            str3=eval(['sprintf("N: %.0f , ",',sample_m,'_neg_size);']);
            str4=eval(['sprintf("Match:%.0f ; ",match_num_',sample_m,'_neg);']);
            str5=eval(['sprintf("Gross Match: %.2f\n",match_rate_',sample_m,'_total);']);
            eval(['total(m,1) = match_rate_',sample_m,'_total;']);
            eval(['match_species_num(m,1) = match_rate_',sample_m,'_total;']);  
            %str = [str1,str2,str3,str4,str5];
            str = str1+str2+str3+str4+str5;
        elseif eval(['match_rate_',sample_m,'_total > 100'])
            str1=eval(['sprintf("Unknown Medicinal Plant: ',sample_m,' No Marker Present\n")']);
            eval(['match_species_num(m,1) = 1000;']);%如果已知某个药味没有筛出特征离子，就在该药味的行处赋一个很大的数字，1000，用于区分正常的匹配度
            str = str1;
        else
            str1=eval(['sprintf("Lack: ',sample_m,', P: %.0f , ",',sample_m,'_size);']);
            str2=eval(['sprintf("Match:%.0f ; ", match_num_',sample_m,');']);
            str3=eval(['sprintf("N: %.0f , ",',sample_m,'_neg_size);']);
            str4=eval(['sprintf("Match:%.0f ; ",match_num_',sample_m,'_neg);']);
            str5=eval(['sprintf("Gross Match: %.2f\n",match_rate_',sample_m,'_total);']);
            eval(['total(m,1) = match_rate_',sample_m,'_total;']);
            eval(['match_species_num(m,1) = match_rate_',sample_m,'_total;']);
            %str = [str1,str2,str3,str4,str5];
            str = str1+str2+str3+str4+str5;
        end
        %string(str_m)='';str_m=["1";"2";"3"];
        
        str_m(size(str_m,1)+1,1)=str;
        %str_m=strcat(str_m,str);
        %str_m=strjoin({str_m,str},'\n');
        %str_m=sprintf('%s\n%s',str_m,str);
        %[str_m+ newline +str];
    end
    
    %根据含有的药味判断是否为目标复方
    eval(['match_num_',formula_name,' = sum(total_match_number);']);
    eval(['match_num_',formula_name,'_neg = sum(total_match_number_neg);']);
    eval(['match_rate_',formula_name,' = match_num_',formula_name,'/sum(total_singFormuNum);']);
    eval(['match_rate_',formula_name,'_neg = match_num_',formula_name,'_neg/sum(total_singFormuNum_neg);']);
    eval(['match_rate_',formula_name,'_total = (match_num_',formula_name,'+match_num_',formula_name,'_neg)/(sum(total_singFormuNum)+sum(total_singFormuNum_neg));']);
    
    if  length(find(total(:,1)>= match_shreshold))>= length(find(match_species_num(:,1)<= 1))%size(match_species_num,1)
        if eval(['match_rate_',formula_name,'_total > match_shreshold'])
            str6=eval(['sprintf("True: ',formula_name,', P:%d , ",sum(total_singFormuNum));']);
            str7=eval(['sprintf("Match: %.0f , ",match_num_',formula_name,');']);%0626xg  %d改成%.0f
            str8=sprintf("N:%d , ",sum(total_singFormuNum_neg));
            str9=eval(['sprintf("Match:%.0f , ",match_num_',formula_name,'_neg);']);
            str10=eval(['sprintf("Gross Match: %.2f\n\n",match_rate_',formula_name,'_total);']); 
            str=str6+str7+str8+str9+str10;
        else
            str6=eval(['sprintf("False: ',formula_name,', P:%d , ",sum(total_singFormuNum));']);
            str7=eval(['sprintf("Match: %.0f , ",match_num_',formula_name,');']);
            str8=sprintf("N:%d , ",sum(total_singFormuNum_neg));
            str9= eval(['sprintf("Match:%.0f , ",match_num_',formula_name,'_neg);']);
            str10= eval(['sprintf("Gross Match: %.2f\n\n",match_rate_',formula_name,'_total);']);
            str=str6+str7+str8+str9+str10;
        end
    else
        str6=eval(['sprintf("False: ',formula_name,', P:%d , ",sum(total_singFormuNum));']);
        str7=eval(['sprintf("Match: %.0f , ",match_num_',formula_name,');']);
        str8=sprintf("N:%d , ",sum(total_singFormuNum_neg));
        str9=eval(['sprintf("Match:%.0f , ",match_num_',formula_name,'_neg);']);
        str10=eval(['sprintf("Gross Match: %.2f\n\n",match_rate_',formula_name,'_total);']);
        str=str6+str7+str8+str9+str10;
    end
    str_m(size(str_m,1)+1,1)=str;
end
clear formula_name formula_compos Area_shreshold delta_rt i index1 index2 index_sample index_sample_neg index_standard index_standard_neg
clear total_match_number total_match_number_neg total_singFormuNum total_singFormuNum_neg Width_shreshold 
clear total standard_neg standard sample_neg sample_m sample 
clear str1 str2 str3 str4 str5 str6 str7 str8 str9 str10 str 
    
T=toc;
    